class Functions:
    def __init__(self):
        self.albums = {"name": "", "name_album": "", "count": 0}
        self.messages = []
        self.send_message = []
        self.sandwich = {"name": "", "foodstuffs": [], "customer": ""}
        self.user_profiles = {"first_name": "",
                              "last_name": "", "location": "", "field": [], }

    def make_shirt(self, size, message):
        if size not in ["big", "small", "medium"]:
            print("The shirt size you want is not available.")
            return
        if size == "big":
            print(f"your shirt size is big and your message I Love Python")
        else:
            print(f"your shirt size is {size} and message is {message} ")

    def describe_city(self, city="Mashhad", country="Iran"):
        print(f"{city.title()} city in the {country.title()} contary")

    def make_album(self, actor, name_album, count=0):
        print("hi enter your actor and name album for album ")
        self.albums["name"] = actor
        self.albums["name_album"] = name_album
        self.albums["count"] = count
        for name, name_album in self.albums.items():
            print(
                f"{name} is create {name_album} album and count music in album is {self.albums[count]}")

    def send_and_show_message(self, opration):
        message = ""
        if opration not in ["1", "2"]:
            print("your opration is undifined")
            return
        if opration == "1":
            self.messages.append[message]
            print("your message ")
        elif opration == "2":
            self.send_message.append(self.messages[:])
            for msg in self.send_message:
                print(f"your send message is:{self.send_message[msg]}")
                print(f"your send message in database:{self.messages}")

    def make_sandwich(self, name, customer="Danial"):
        self.sandwich["name"] = name
        self.sandwich["customer"] = customer
        while True:
            if foodstuffs == "done":
                break
            foodstuffs = input(
                f"enter your foodstuffs {name} sandwich and for done enter done\nyour foodstuffs:")
            self.sandwich["foodstuffs"].append(foodstuffs)

        print(f"your foodstuffs in sandwich:{self.sandwich}")

    def make_user_profile(self, first_name, last_name, location):
        self.user_profiles["first_name"] = first_name
        self.user_profiles["last_name"] = last_name
        self.user_profiles["location"] = location
        while True:
            if field == "done":
                break
            field = input(
                "Hello, enter the skills you have and enter the word 'done' to exit.")
            self.user_profiles["field"].append(field)
        print(
            f"Thank you for entering your information and your account information: {self.user_profiles}")
