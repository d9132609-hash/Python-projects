from functions import Functions
from part1.practical_items import PracticalItems
fun = Functions()



def controller_functions(pi):
    print("Hello, welcome to the sixth chapter. Here you can check the operations related to the changes.")
    while True:
        part1 = "1-make shirt\n2-describe city\n3-make album\n4-send and show message\n5-make sandwich"
        part1 += "\n6-make user profile\n7-exit"
        opration = input(f"Opration:\n{part1}")
        if opration == "1":
            while True:
                city = input("Enter the city you want to travel to:").lower()
                contary = input(
                    "Now enter the name of the country in which that city is located:").title()
                fun.make_shirt(city, contary)
                if pi.questions == "no":
                    break
        elif opration == "2":
            while True:
                size = input(
                    "Enter your size shirt:(small/medium/big)").lower()
                message = input("Enter your message for shirt:").title()
                fun.make_shirt(size, message)
                if pi.questions == "no":
                    break
        elif opration == "3":
            while True:
                musician = input("Enter the name of a musician:").title()
                name_album = input(
                    "Enter  the name of one of their albums that you really like:").title()
                count = input("Enter the number of songs on that album:")
                fun.make_album(musician, name_album, count)
                if pi.questions == "no":
                    break
        elif opration == "4":
            while True:
                message = "Hello, welcome to my messenger.\nOprations:\n1-send message\n2-show message\nEnter number your opration:"
                select = input(message).lower()
                fun.send_and_show_message(select)
                if pi.questions == "no":
                    break
        elif opration == "5":
            print("Hello, welcome to Mohammad Taghizadeh's sandwich shop.")
            while True:
                name_sandwich = input(
                    "Enter the name of the sandwich you are looking for:").title()
                customer = input("Enter your name please:").title()
                fun.make_sandwich(name_sandwich, customer)
                if pi.questions == "no":
                    break
        elif opration == "6":
            print("Hello, welcome to Mohammad Taghizadeh's website.")
            while True:
                first_name = input("Enter the name :").title()
                last_name = input("Enter your name please:").title()
                location = input(
                    "Enter the name of the country you live in:").title()
                fun.make_sandwich(first_name, last_name, location)
                if pi.questions == "no":
                    break
        elif opration == "7":
            while True:
                if pi.exit() == "yes":
                    break
        else:
            print(
                "The desired operation does not exist. Please re-enter the desired operation.")
            continue
