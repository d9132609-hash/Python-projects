class Variables:
    def __init__(self):
        self.message = " "

    def print_message(self):
        if self.message == " ":
            print("you don't have a message")

        print(f"your message:{self.message}")

    def write_message(self, message):
        self.message = message
        print(f"Your new message:{message.strip()}")

    def personal_message(self, personal):
        print(f"Hi{personal} {self.message} ?")

    def famous_quote(self, personal, say):
        print(f"{personal.title()} once said,'{say}'")

    def file_name(self, filename):
        print(
            f"Your file is {filename} and your file name is {filename.removesuffix(".txt")}")

    def calculater(self, opration):
        number1 = int(input("Enter your first number:"))
        number2 = int(input("Enter your second number:"))

        if opration == 1:
            print(f"your addition numbers: {number1+number2}")
        elif opration == 2:
            print(f"your addition numbers: {number1-number2}")
        elif opration == 3:
            print(f"your addition numbers: {number1*number2}")
        elif opration == 4:
            print(f"your addition numbers: {number1/number2}")
        else:
            print("sorry your opration is undefined")

    def favorite_number(self, number):
        print(f"your favorite number is {number}")


new_varible = Variables()
new_varible.file_name("python.txt")
