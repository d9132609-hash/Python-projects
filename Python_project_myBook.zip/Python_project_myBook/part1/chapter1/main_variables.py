
import variables 


new_var =variables.Variables()

def controller_varible(pi):

    print("Hello, welcome to the first chapter. Here you can check the operations related to the changes.")
    while True:
        part1 = "1-print message\n2-Guest reviews\n3-personal message"
        part2 = "4-famous quote\n5-file name\n6-calculater"
        part3 = "7-favorite number\n8-exit\nEnter your opration please:"
        opration = input(f"Oprations:\n{part1}\n{part2}\n{part3}")
        if opration == "1":
            while True:
                new_var.print_message()
                if pi.questions() == "no":
                    break
        elif opration == "2":
            while True:
                message = input("Enter your message please:").strip()
                new_var.write_message(message)
                if pi.questions() == "no":
                    break
        elif opration == "3":
            while True:
                name = input(
                    "Write the name of the person you want to send the message to:").strip()
                new_var.personal_message(name)
                if pi.questions() == "no":
                    break
        elif opration == "4":
            while True:
                name = input("Write the name of the person who said this:").strip()
                say = input("Enter what (she/he) said:").strip()
                new_var.famous_quote(name, say)
                if pi.questions() == "no":
                    break
        elif opration == "5":
            while True:
                file = input("Enter you are name file:no").strip()
                new_var.file_name(file)
                if pi.questions() == "no":
                    break
        elif opration == "6":
            while True:
                opration = int(input(
                    "Enter your opration\n1-addition\n2-subtraction\n3-multiplication\n4-division"))
                new_var.calculater(opration)
                if pi.questions() == "no":
                    break
        elif opration == "7":
            while True:
                number = input("Enter your favorite number").strip()
                new_var.write_message(number)
                if pi.questions() == "no":
                    break
        elif opration == "8":
            if pi.exit=="yes":
                pi.exit()
                break
        else:
            print(
                "The desired operation does not exist. Please re-enter the desired operation.")
            continue

