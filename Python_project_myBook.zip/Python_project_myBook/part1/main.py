import chapter1.main_variables as va
import chapter2.main_lists as l
import chapter3.main_advanced_list as al
import chapter4.main_conditional_expressions as ce
import chapter5.main_dictionary as di
import chapter6.main_loops_and_inputs as lai
import chapter7.main_functions as fun
import chapter8.main_classes as c
import chapter9.main_file  as f
import chapter10.main_tests as t
from practical_items import PracticalItems as pi


def controller_part1():

    print("Hello, welcome to the first part. you can choose operations for each chapter.")
    while True:
        part1 = "1-varibles\n2-lists\n3-advenced lists\n4-conditional expressions"
        part2 = "5-dictionarys\n6-loops and inputs\n7-functions\n8-classes"
        part3 = "9-files\n10-tests\n11-exit\nEnter your opration please:"
        opration = input(f"Oprations:\n{part1}\n{part2}\n{part3}")
        if opration == "1":
            while True:
                va.controller_varible(pi)
                if pi.questions() == "no":
                    break
        elif opration == "2":
            while True:
                l.controller_list(pi)
                if pi.questions() == "no":
                    break
        elif opration == "3":
            while True:
                al.controller_advenced_list(pi)
                if pi.questions() == "no":
                    break
        elif opration == "4":
            while True:
                ce.controller_conditional_expressions(pi)
                if pi.questions() == "no":
                    break
        elif opration == "5":
            while True:
                di.controller_dictionary(pi)
                if pi.questions() == "no":
                    break
        elif opration == "6":
            while True:
                lai.controller_loops_and_inputs(pi)
                if pi.questions() == "no":
                    break
        elif opration == "7":
            while True:
                fun.controller_functions(pi)
                if pi.questions() == "no":
                    break
        elif opration == "8":
            while True:
                c.controller_classes(pi)
                if pi.questions() == "no":
                    break
        elif opration == "9":
            while True:
                f.controller_files(pi)
                if pi.questions() == "no":
                    break
        elif opration == "10":
            while True:
                t.controller_tests(pi)
                if pi.questions() == "no":
                    break

        elif opration == "11":
            if pi.exit == "yes":
                pi.exit()
                break
        else:
            print(
                "The desired operation does not exist. Please re-enter the desired operation.")
            continue


controller_part1()
