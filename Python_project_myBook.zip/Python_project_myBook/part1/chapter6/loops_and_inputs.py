class LoopsAndInputs:
    def __init__(self):
        self.foodstuffs = []
        self.sandwich_orders = []
        self.finished_sandwichs = []
        self.responses = {}

    def foodstuffs_pizza(self):
        print("Enter the ingredients you would like to add to your pizza and press the word 'Done' to finish.")
        while True:
            pizza = input("Enter your foodstuffs:").lower()
            self.foodstuffs.append(pizza)
            if pizza == "done":
                print(
                    f"Thank you for your order. Your pizza with {self.foodstuffs} will be ready in two minutes.")
                break

    def buy_tickets(self):
        print(
            "Hello, welcome to Hoveyzeh Cinema. Please enter your age to purchase a ticket.")
        while True:
            age = int(input("Your age:"))
            if age <= 0:
                print("Your age is invalid.")
            elif age <= 3:
                print("Your ticket is free, please.")
            elif 3 < age <= 12:
                print("Your ticket is 12 dollers, please.")
            else:
                print("Your ticket is 15 dollers, please.")
            quesion = input(
                "Do you still want to buy a ticket?(yes/no)").lower()
            if quesion == "yes":
                continue
            elif quesion == "no":
                break
            print("Enjoy your movie purchase.")

    def create_sandewich(self):
        while True:

            meno = "Hello, welcome to Mohammad Taghi Radeh's sandwich shop.\n "
            meno += "Please choose the sandwich you want from the menu, and you can choose:\n"
            meno += "1-Bandari\n2-hamburger\n3-steak\n4-cheeseburger\n5-pastrami\n6-done: "
            meno += "Enter your sandwich:"
            sandwich = input(meno).lower()
            if sandwich in ["bandari", "Hamburger", "Steak", "Cheeseburger", "Pastrami"]:
                self.sandwich_orders.append(sandwich)
                continue
            elif sandwich == "done":
                print(
                    f"Thank you for your purchases and your sandwiches:{self.sandwich_orders}")
                break
            else:
                print("Sorry, your sandwich is out of stock.")
        self.finish_sandewiches()

    def finish_sandewiches(self):
        for sandewich in self.sandwich_orders:
            print(
                f"Your {self.sandwich_orders[sandewich]}r sandwich is ready.")
            self.sandwich_orders.remove(sandewich)
            self.finished_sandwichs.append[sandewich]
            print(f"your sandwichs is : {self.finished_sandwichs}")

    def holiday(self):

        while True:
            name = input("Enter your name:")
            quesion = "Which of the following places would you like to travel to for a vacation: ?"
            quesion += "\n1-Tehran\n2-Mashhad\n3-Karaj\n4-Isfahan\n5-Khuzestan\n6-exit\nplease enter your place:"
            if name == "exit":
                print("Thank you very much for participating in the survey.")
                break
            place = input(quesion)
            if place not in ["tehran", "mashhad", "karaj", "isfahan", "khuzestan", "exit"]:
                print("your place is out of stock. ")
                continue
            if place == "exit":
                print("Thank you very much for participating in the survey.")
                break

            self.responses[name] = place
        print("\n for result:")
        for name, response in self.responses.items():
            print(f"{name} is like teravel is {response} place")
