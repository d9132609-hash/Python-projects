from part1.practical_items import PracticalItems
from loops_and_inputs import LoopsAndInputs
new_lai = LoopsAndInputs()



def controller_loops_and_inputs(pi):

    print("Hello, welcome to the sixth chapter. Here you can check the operations related to the changes.")
    while True:
        part1 = "1-foodstuffs_pizza\n2-buy_tickets\n3-create_sandewich"

        part2 = "4-holiday\n5-exit\nEnter your opration please:"
        opration = input(f"Oprations:\n{part1}\n{part2}")
        if opration == "1":
            while True:
                new_lai.foodstuffs_pizza()
                if pi.questions() == "no":
                    break
        elif opration == "2":
            while True:

                new_lai.buy_tickets()
                if pi.questions() == "no":
                    break
        elif opration == "3":
            while True:

                new_lai.create_sandewich()
                if pi.questions() == "no":
                    break
        elif opration == "4":
            while True:

                new_lai.holiday()
                if pi.questions() == "no":
                    break

        elif opration == "5":
            if pi.exit()=="yes":
                break
        else:
            print(
                "The desired operation does not exist. Please re-enter the desired operation.")
            continue


