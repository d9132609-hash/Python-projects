class User:
    def __init__(self):
        self.user = {"first_name": "Danial",
                     "last_name": "Mohammad taghizadeh",
                     "city": "Mashhad", "countary": "Iran"}
        self.login_attempts = 0

    def describe_user(self):
        first_name = input("Enter your name:")
        last_name = input("Enter your last name:")
        city = input("Enter your name of city:")
        countary = input("Enter your name of countary:")
        self.user["first_name"] = first_name
        self.user["last_name"] = last_name
        self.user["city"] = city
        self.user["countary"] = countary
        print(f"your user: {self.user}")
        print(f"Hello {self.user["first_name"]} wellcome to my website")

    def increment_login_attempts(self):
        login = self.login_attempts+1
        print(f"{login} user is login to website.")

    def resert_login_attempts(self):
        self.login_attempts = 0
        print("website is resert and 0 user is login.")


class Admin(User):
    def __init__(self):
        super().__init__()
        self.privileges = ["1-can ban user",
                           "2-can delete post", "3-can add user"]

    def show_privileges(self):
        name = input("Hello manager enter your name please:")
        print(
            f"hi {name} manager As a website administrator, you can do the following:")
        for privilege in self.privileges:
            print(privilege)
