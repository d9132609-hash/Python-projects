from loky import Die
from restaurant import Restaurant, IceCreamStand
from user import User, Admin

new_res = Restaurant()
new_ic = IceCreamStand()
new_us = User()
new_ad = Admin()



def controller_classes(pi):

    print("Hello, welcome to the Eighth. chapter. Here you can check the operations related to the changes.")
    while True:
        part1 = "1-Restaurant\n2-Website\n3-exit\nEnter your opration please:"

        opration = input(f"Oprations:\n{part1}")
        if opration == "1":
            while True:
                print("Welcome to the restaurant. Select the operation you want: ")

                restorant = "1-describe_restaurant \n2-open_restaurant \n3-increment_number_served\n4-show_flovors_ice_cream\n5-exit\nEnter your opration please:"
                oprations = input(f"Oprations:\n{restorant}")
                if oprations == "1":
                    while True:

                        new_res.describe_restaurant()
                        if pi.questions() == "no":
                            break
                elif oprations == "2":
                    while True:
                        clock = input("Hello, what time would you like to reserve a table for?")
                        new_res.open_restaurant(clock)
                        if pi.questions() == "no":
                            break
                elif oprations == "3":
                    while True:

                        new_res.increment_number_served()
                        if pi.questions() == "no":
                            break
                elif oprations == "4":
                    while True:

                        new_ic.show_flovors_ice_cream()
                        if pi.questions() == "no":
                            break
                elif oprations == "5":
                     if pi.exit() == "yes":
                        break
        elif opration == "2":
            while True:
                print("Welcome to the website. Select the operation you want: ")

                restorant = "1-describe_user \n2-increment_login_attempts \n3-resert_login_attempts\n4-show_privileges\n5-exit\nEnter your opration please:"
                oprations = input(f"Oprations:\n{restorant}")
                if oprations == "1":
                    while True:

                        new_us.describe_user()
                        if pi.questions() == "no":
                            break
                elif oprations == "2":
                    while True:

                        new_us.increment_login_attempts()
                        if pi.questions() == "no":
                            break
                elif oprations == "3":
                    while True:

                        new_us.resert_login_attempts()
                        if pi.questions() == "no":
                            break
                elif oprations == "4":
                    while True:

                        new_ad.show_privileges()
                        if pi.questions() == "no":
                            break

        elif opration == "3":
            if pi.exit() == "yes":
                break
        else:
            print(
                "The desired operation does not exist. Please re-enter the desired operation.")
            continue
