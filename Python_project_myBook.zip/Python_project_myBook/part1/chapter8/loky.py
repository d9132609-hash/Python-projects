# import random
from random import randint, choice


class Die:
    def __init__(self):
        self.sides = 6
        self.loky = [1, 2, 3, 4, "Danial", "Aref", "Diana", "Ali", "Reza"]
        self.my_ticket = [1, 2, 3, 4, "Danial", "Aref", "Diana", "Ali", "Reza"]

    def roll_die(self):
        roll = int(input("Enter your roll for die:"))
        rolls = int(input("Enter if you roll the dice: "))
        for i in range(rolls):
            if i == 0:
                print(f"{randint(0, roll)} in {roll} die for 1")
            else:
                print(f"{randint(0, roll)} in {roll} die for {i}")

    def show_loky(self):
        lok = input("enter your choice:").title()
        choices = choice(self.loky)

        if lok == choices:
            print("you have win a 1,000,000$")

        else:
            print(f" sorry you choice {lok} but win is {choices}")

    def my_loky(self):
        i = 1
        while True:
            lok = choice(self.my_ticket)
            choices = choice(self.loky)
            if lok == choices:
                print(f"you have win a 1,000,000$ for {i}")
                break
            else:
                print(f" sorry you choice {lok} but win is {choices}")
                i += 1
                continue


d = Die()
d.my_loky()
