class Restaurant:
    def __init__(self):
        self.restaurant_name = "Mohhamad taghizadeh"
        self.cuisine_type = "sandwich"
        self.number_served = 0

    def describe_restaurant(self):
        restaurant = input("Enter your name restaurant:")
        cuisine = input(
            "Enter the type of food you want to serve in your restaurant:")
        self.restaurant_name = restaurant
        self.cuisine_type = cuisine
        print(
            f"Hello, welcome to {self.restaurant_name} Restaurant. We prepare {self.cuisine_type} dishes in this restaurant.")

    def open_restaurant(self, clock):
        if 8 <= clock < 22:
            print(
                f"Restaurant is open . welcome to {self.restaurant_name} restaurant.")
        else:
            print(f"sorry restaurant {self.restaurant_name} is close. ")

    def increment_number_served(self):
        served = self.number_served+1
        print(f"1 served to custumer and serveds is {served}")


class IceCreamStand(Restaurant):
    def __init__(self):
        super().__init__()
        self.flovors = ["Chocolate", "cantaloupe",
                        "strawberry", "vanilla",  "blueberry"]

    def show_flovors_ice_cream(self):
        print(
            f"Hello, welcome to {self.restaurant_name} Restaurant. We prepare {self.cuisine_type} dishes in this restaurant.\n Menu:")
        
        i=1
        for flovor in self.flovors:
            print(f"{i}-{flovor}")
            i+=1
        test=int(input("Enter the number of your desired pastry flavor:"))
        if test not in [1,2,3,4,5]:
            print(" Sorry your ice cream flavor is not available.")
            return
        else:
            print(" Your ice cream will be ready soon. Thank you for your purchase. ")
