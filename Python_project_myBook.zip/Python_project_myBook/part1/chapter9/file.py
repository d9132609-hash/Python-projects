from pathlib import Path
import json


class Files:
    def __init__(self):
        self.learns = []
        self.guests = []
        self.users = []

    def learn_langue_programming(self):

        try:
            path = Path(
                "C:/Users/duke laptop/Desktop/My Projects/Python_project_myBook/part1/chapter9/learn.txt")
        except:
            print("your file is undefined")
        else:
            langue = input("Enter your langue forever:").title()

            container = path.read_text()

            contents = json.loads(container)

        for line in contents:
            new_line = line.replace("python", langue)
            print(new_line)
        print(f"your total number of learned is {len(contents)}")

    def write_learn_langue_programming(self):
        write = input("Enter your learn in forever langue programming: ").title()
        try:
            path = Path(
                "C:/Users/duke laptop/Desktop/My Projects/Python_project_myBook/part1/chapter9/learn.txt")
        except:
            print("your file is undefined")
        else:

            self.learns.append(write)
            contents = json.dumps(self.learns)
            path.write_text(contents)

            print(f"your text was added successfully to the learn.txt file .")

    def create_guest(self):

        try:
            path = Path(
                "C:/Users/duke laptop/Desktop/My Projects/Python_project_myBook/part1/chapter9/guest.txt")
        except:
            print("your file is undefined")
        else:
            while True:
                text = "Hi , welcome to my party , please enter your visitor 's name and type it out to enter exit."
                name = input(f"{text}\nEnter your name guests:").title()
                if name == "exit":
                    break

                self.guests.append(name)
                contents = json.dumps(self.guests)
                path.write_text(contents)
                print(f"Hi {name} welcome to my party. ")
            print("your guest list is added successfully")

    def show_guest(self):
        try:
            path = Path(
                "C:/Users/duke laptop/Desktop/My Projects/Python_project_myBook/part1/chapter9/guest.txt")
        except:
            print("your file is undefined")
        else:
            print("Guest in party:")
            container = path.read_text()
            contents = json.loads(container)

            for guest in contents:
                print(f"your guest is party have name:{guest}")
            print(f"your total number of guests is {len(contents)}")

    def calculator(self):

        while True:
            operation = input(
                "Welcome to my calculate\n1-sum\n2-sub\n3-mul\n4-dev\n5-exit\nEnter your operation:")
            if operation in ["1", "2", "3", "4"]:

                try:
                    number1 = int("Enter your first number: ")
                    number2 = int("Enter your first number: ")
                except ValueError:
                    print("your type value is false")
                if operation == "1":
                    print(f"your addition  numbers is {number1 + number2}")
                elif operation == "2":
                    print(f"your subtraction numbers is {number1 - number2}")
                elif operation == "3":
                    print(
                        f"your multiplication numbers is {number1 * number2}")
                elif operation == "4":
                    try:
                        division = number1 / number2
                    except ZeroDivisionError:
                        print("you can't division by 0.")
                    else:
                        print(f"your division numbers is {division}")
            elif operation == "5":
                print("thank you for using my car , i hope you have a good day .")
                break
            else:
                print(
                    "you don 't have your intended operations , please enter your desired operation again")
                continue

    def favorite_number(self):
        try:
            path = Path(
                "C:/Users/duke laptop/Desktop/My Projects/Python_project_myBook/part1/chapter9/learn.txt")
        except FileNotFoundError:
            print("your file is undefined")
        else:
            if path.exists():
                contains = path.read_text()
                container = json.loads(contains)
                print(f"I know your favorite number is {container}")
            else:
                number = input("Enter your favorite number:")
                contains = json.dumps(number)
                container = path.write_text(contains)
                print("your favorite number is saved successfully")

    def remember_user(self):
        text = "hi to our website please enter your user information and set user permissions id to zero to get out of the user 's.\n"
        while True:
            try:
                path = Path(
                    "C:/Users/duke laptop/Desktop/My Projects/Python_project_myBook/part1/chapter9/user.txt")
                id = int(input(f"{text}Enter your user id : "))
                if id == 0:
                    break
                first_name = input("Enter your user first name : ").title()
                last_name = input("Enter your  last name : ").title()
                location = input("Enter your country : ").title()
            except ValueError or FileNotFoundError:
                print("your data type for data is false")
            else:

                user = {
                    "id": "",
                    "first_name": "",
                    "last_name": "",
                    "location": "",
                }
                user["id"]=id
                user["first_name"]=first_name
                user["last_name"]=last_name
                user["location"] = location
                self.users.append(user)
                contains = json.dumps(self.users)
                print("your user profile successfully")
        path.write_text(contains)
        container = path.read_text()
        contain = json.loads(container)

        print(f"your users:\n ")
        for id  in contain:
            print(f"your data user:{id}")



