from file import Files

new_f = Files()



def controller_files(pi):
    print("Hello, welcome to the ninth chapter. Here you can check the operations related to the changes.")
    while True:
        part1 = "1-write_learn_langue_programming\n2-learn_langue_programming\n3-create_guest\n4-show_guest"
        part2 = "5-favorite_number\n6-remember_user\n7-calculator\n8-exit"
        part3 = "Enter your opration please:"
        oprations = input(f"Oprations:\n{part1}\n{part2}\n{part3}")

        if oprations == "1":
            while True:

                new_f.write_learn_langue_programming()
                if pi.questions() == "no":
                    break
        elif oprations == "2":
            while True:

                new_f.learn_langue_programming()
                if pi.questions() == "no":
                    break
        elif oprations == "3":
            while True:

                new_f.create_guest()
                if pi.questions() == "no":
                    break
        elif oprations == "4":
            while True:

                new_f.show_guest()
                if pi.questions() == "no":
                    break
        elif oprations == "5":
            while True:

                new_f.favorite_number()
                if pi.questions() == "no":
                    break
        elif oprations == "6":
            while True:

                new_f.remember_user()
                if pi.questions() == "no":
                    break
        elif oprations == "7":
            while True:

                new_f.calculator()
                if pi.questions() == "no":
                    break

        elif oprations == "8":
            if pi.exit() == "yes":
                break


