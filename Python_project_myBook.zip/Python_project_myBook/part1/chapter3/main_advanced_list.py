from advanced_list import AdvancedList

new_list = AdvancedList()



def controller_advenced_list(pi):
    print("Hello, welcome to the Third chapter. Here you can check the operations related to the changes.")
    while True:
        part1 = "1-Create a pizza list\n2-Guest a animal list\n3-operation of numbers between two numbers"
        part2 = "4-power of numbers\n5-print list (pizzas or animals)\n6-exit\nEnter your operation please:"

        operation = input(f"operations:\n{part1}\n{part2}")
        if operation == "1":
            while True:
                number = int(input("Please enter the number of pizza:"))
                new_list.create_list_pizza(number)
                if pi.questions() == "no":
                    break
        elif operation == "2":
            while True:
                number = int(input("Enter the names of animals that are in this animal category:"))
                new_list.create_list_animal(number)
                if pi.questions() == "no":
                    break
        elif operation == "3":
            while True:
                number = int(input(
                    "Operations between two numbers:\n1-even\n2-odd\n3-sum\n4-multiple numbers\nenter your operation: "))

                new_list.operation_of_numbers_between_two_numbers(number)
                if pi.questions() == "no":
                    break
        elif operation == "4":
            while True:
                new_list.power_of_numbers()

                if pi.questions() == "no":
                    break
        elif operation=="5":
            number=int(input("1-print list pizza\n2-print list animals\n Enter your number list:"))
            new_list.print_list(number)

        elif operation == "6":
            if pi.exit() == "yes":
                break
        else:
            print(
                "The desired operation does not exist. Please re-enter the desired operation.")
            continue


