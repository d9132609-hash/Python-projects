


def operation_of_numbers_between_two_numbers(operation):
    number = 0
    if operation == 1:
        number = 1
    elif operation == 2:
        number = 2
    elif operation == 4:
        number = int(
            input("Enter the multiple of your desired numbers between these two numbers:"))

    return number


def animal_category(number):
    animal_category_name = ""
    message = ""
    if number == 1:
        animal_category_name = "Birds"
        message = "and all animals in this group lay eggs"
    elif number == 2:
        animal_category_name = "Mammals"
        message = "and most animals in this group breathe on land"
    elif number == 3:
        animal_category_name = "Amphibians"
        message = "and all animals in this group have low body temperatures"
    elif number == 4:
        animal_category_name = "Reptiles"
        message = "and all animals in this group live on both land and water"
    elif number == 5:
        animal_category_name = "Aquatic animals"
        message = "and all animals in this group live in water."
    full_message = f"{animal_category_name} category {message}"
    return full_message





class AdvancedList:
    def __init__(self):
        self.list_pizza = []
        self.list_animal = []

    def create_list_pizza(self, number):
        number=1
        for n in range(number+1):
            
            pizza = input("Please enter the name of the pizza you want:")
            self.list_pizza.append(pizza)
            print(f"{n}-Ordered pizza:{pizza}")
            number+=1
        print("All the pizzas you ordered are ready.")

    def create_list_animal(self, number):
        x=1
        name_anmial = animal_category(number)
        number_animal = int(input(
            "Enter the number of animals you want to use as examples for this category:"))
        if number in [1, 2, 3, 4, 5]:
            for n in range(number_animal):
                animal = input(
                    "Enter your number animals:")
                self.list_animal.append(animal)
                print(f"{x}-animal {animal} added to the list")
                x+=1
        else:
            print("The animal category you are looking for is not in the list.")
        print(
            f"{self.list_animal} is {name_anmial}")

    def print_list(self, operation):
        number = 1
        if operation == 1:
            for i in self.list_pizza:
                print(f"{number}-{i}")
        elif operation == 2:
            for i in self.list_animal:
                print(f"{number}-{i}")

    def operation_of_numbers_between_two_numbers(self, operation):
        operations = operation_of_numbers_between_two_numbers(operation)
        if operation in [1, 2, 3, 4]:

            number1 = int(input("Enter your number1:"))
            number2 = int(input("Enter your number2:"))
            sum = 0
            for n in range(number1, number2, operations):
                if operation == 1:
                    print(
                        f"The even of the numbers between {number1} and {number2} is equal to:{n}")
                elif operation == 2:
                    print(
                        f"The odd of the numbers between {number1} and {number2} is equal to:{n}")
                elif operation == 4:
                    print(
                        f"The multiple numbers {operations} of the numbers between {number1} and {number2} is equal to:{n}")
                else:
                    sum += n
                    print(
                        f"The sum of the numbers between {number1} and {number2} is equal to:{sum}")
        else:
            print("your operation is not a  found")

    def power_of_numbers(self):
        number = int(input("Enter your number please:"))
        power = int(input("Enter the desired power of your number:"))
        print(f"{number} to power {power}={number**power}")


