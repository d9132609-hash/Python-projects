class ConditionalExpressions:
    def __init__(self):
        self.my_favorite_fruits = ["banna", "pineapple", "apple"]
        self.current_user = ["Daniall mohammad taghizadeh",
                             "Ali check", "Reza moradi", "Mohammad seid aghayi"]
        
    def alien_color(self):
        sum = 0
        index = 1
        number = int(input("How many aliens have you defeated in the game?"))
        for i in range(number):
            color = input(
                f"Enter the color of the {index} spaceman:(grren,yellow,red)")
            index += 1
            if color == "red":
                print(
                    "Congratulations, you received 10 points for defeating this alien.")
                sum += 10
            elif color == "yellow":
                print("Congratulations, you received 5 points for defeating this alien.")
                sum += 5
            elif color == "grren":
                print("Congratulations, you received 1 points for defeating this alien.")
                sum += 1
            else:
                print("Unfortunately, this alien you defeated is worthless.")

        print(f"Your total points from defeating aliens is equal to:{sum}")

    def stages_of_life(self):
        age = int(input("Enter your age please:"))
        if age <= 0:
            print("your age is false")
        elif 0 < age <= 20:
            print(
                f"You are {age} years old, which means you are in the spring of your life")
        elif 20 < age <= 40:
            print(
                f"You are {age} years old, which means you are in the summer of your life")
        elif 40 < age <= 60:
            print(
                f"You are {age} years old, which means you are in the fall of your life")
        else:
            print(
                f"You are {age} years old, which means you are in the winter of your life")

    def favorite_fruits(self):
        fruit = input("Enter your favorite fruit:").lower()
        if fruit in self.my_favorite_fruits:
            print(f"You like {fruit}, I love them too")
        else:
            print(f"You like {fruit},they must be a delicious fruit.")
    def admin_user(self):
        login=input("Hello, welcome to our website. Which of the following positions do you have?(admin/user)").lower()
        if login=="admin":
            name=input("Enter your name please:")
            if name=="Danial mohammad taghizadeh":
                print("Hi admin mr.mohammad taghizadeh welcome to your website")
            else:
                print("Sorry, but you are not an administrator and do not have access.")
        elif login=="user":
            user=input("1-new user\n2-current user\nEnter your user type:")
            name=input("Enter your name please:")
            if user=="1":
                self.current_user.append(name)
                print("Your name was successfully added.")
            elif user=="2":
                if user in self.current_user:
                    print(f"Hi {name} welcome to your website")
                else:
                    print("Your name is not in the user list. Please log in using the new user option.")
    def ordinal_numbers(self):
        number= int(input("Enter your number please:"))
        if number==1:
            print("your Ordinal number is:1st")
        elif number==2:
            print("your Ordinal number is:2nd")
        elif number==3:
            print("your Ordinal number is:3rd")
        else:
            print(f"your Ordinal number is:{number}th")











