from conditional_expressions import ConditionalExpressions
from part1.practical_items import PracticalItems
ce = ConditionalExpressions()



def controller_conditional_expressions(pi):
    print("Hello, welcome to the Third chapter. Here you can check the operations related to the changes.")
    while True:
        part1 = "1-Spaceman hunt\n2-Stages of life\n3-Favorite fruits"
        part2 = "4-Login to webside\n5-Ordinal numbers\n6-exit\nEnter your opration please:"

        opration = input(f"Oprations:\n{part1}\n{part2}")
        if opration == "1":
            while True:
                ce.alien_color()
                if pi.questions() == "no":
                    break

        elif opration == "2":
            while True:
                ce.stages_of_life()
                if pi.questions() == "no":
                    break
        elif opration == "3":
            while True:
                ce.favorite_fruits()
                if pi.questions() == "no":
                    break
        elif opration == "4":
            while True:

                ce.admin_user()
                if pi.questions() == "no":
                    break
        elif opration == "5":

            while True:
                ce.ordinal_numbers()
                if pi.questions() == "no":
                    break

        elif opration == "6":
            if pi.exit() == "yes":
                break
        else:
            print(
                "The desired operation does not exist. Please re-enter the desired operation.")
            continue



