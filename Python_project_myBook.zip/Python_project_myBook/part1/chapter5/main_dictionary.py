
from dictionary import Dictionary
new_dic = Dictionary()



def controller_dictionary(pi):

    print("Hello, welcome to the fifth chapter. Here you can check the operations related to the changes.")
    while True:
        part1 = "1-people\n2-show_list_people\n3-create_pet"
        part2 = "4-show_list_pet\n5-favorite_places\n6-show_list_places"
        part3 = "7-exit\nEnter your opration please:"
        opration = input(f"Oprations:\n{part1}\n{part2}\n{part3}")
        if opration == "1":
            while True:
                new_dic.people()
                if pi.questions() == "no":
                    break
        elif opration == "2":
            while True:
                
                new_dic.show_list_people()
                if pi.questions() == "no":
                    break
        elif opration == "3":
            while True:

                new_dic.create_pet()
                if pi.questions() == "no":
                    break
        elif opration == "4":
            while True:

                new_dic.show_list_pet()
                if pi.questions() == "no":
                    break
        elif opration == "5":
            while True:

                new_dic.favorite_places()
                if pi.questions() == "no":
                    break
        elif opration == "6":
            while True:

                new_dic.show_list_places()
                if pi.questions() == "no":
                    break

        elif opration == "7":
            if pi.exit == "yes":
                pi.exit()
                break
        else:
            print(
                "The desired operation does not exist. Please re-enter the desired operation.")
            continue

