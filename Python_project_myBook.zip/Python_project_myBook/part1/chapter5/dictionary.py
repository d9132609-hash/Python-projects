

class Dictionary:
    def __init__(self):
        self.users = []
        self.pets = {}
        self.favorite_place = {}
        self.counts = 0

    def people(self):
        print("Hello, welcome to the registration section. Please enter the requested information.")
        first_name = input("Enter your first name:")
        last_name = input("Enter your last name:")
        city = input("Enter the name of the city where you live:")
        email = input("Enter your email:")

        user = {
            "first_name": first_name.title().strip(),
            "last_name": last_name.title().strip(),
            "city": city.title().strip(),
            "email": email.strip(),

        }

        self.users.append(user)
        full_name = f"{first_name} {last_name}"
        print(f"{full_name} information was successfully added.")

    def show_list_people(self):
        self.people()
        print("Your user list is as follows:")
        for user in self.users:
            print(user)
        print(f"Number of users:{len(self.users)}")

    def create_pet(self):
        print("Hello, welcome to Beautiful Animal Veterinary Clinic.")
        type = input("Please enter your animal type:").strip().lower()
        if type not in ["cat", "dog", "fish"]:
            print(
                f"Sorry, but we do not provide services specifically for {type}.")
        else:
            name_animal = input(
                "please enter your animal name:").strip().lower().title()
            animal_owner = input(
                "please enter your  name:").strip().lower().title()

            dog = {
                "animal_owner": animal_owner,
                "name_animal": name_animal,

            }
            cat = {
                "animal_owner": animal_owner,
                "name-animal": name_animal,

            }
            fish = {
                "animal_owner": animal_owner,
                "name_animal": name_animal,

            }
            if type == "dog":
                dog["doctor"] = "Reza moradi"
                self.pets["dog"] = dog
            elif type == "cat":
                cat["doctor"] = "Maram verdi porazad"
                self.pets["cat"] = cat
            elif type == "fish":
                fish["doctor"] = "Alireza check"
                self.pets["fish"] = fish

    def show_list_pet(self):

        for type_pet, pet in self.pets.items():
            if type_pet in ["dog", "cat", "fish"]:
                print("List of all animals treated at the veterinary clinic:")
                print(f"type animal:{type_pet}")
                print(f"name animal:{pet["name_animal"]}")
                print(f"animal owner:{pet["animal_owner"]}")
                print(f"doctor:{pet["doctor"]}")

        print(f"Total number of animals treated:{len(self.pets)}")

    def favorite_places(self):
        print("Hello, Welcome to the Iran Travel Guide. Select one of the following provinces for your trip to visit.")
        print("1-Mashhad\n2-Tehran\n3-Isfahan")
        name = input("Enter your favorite place:").strip().lower()
        if name not in ["mashhad", "tehran", "isfahan"]:
            print("The place you are looking for is not in the list.")
        else:
            count = int(input("Enter the desired amount for the trip:"))
            self.counts += count
            tehran = {"main_city": "Tehran",
                      "places_of_interest": ["Bazaar of tehran", "Mosque of tehran", "Mosque of tehran"],
                      "ticket_prices": 20000,
                      "guide": "Reza moradi",
                      "capacity": "29 person",
                      }
            mashhad = {"main_city": "Mashhad",
                       "places_of_interest": ["Imam Reza Shrine", "Gohar Shad Mosque", "Vakil Abad Park"],
                       "ticket_prices": 30000,
                       "guide": "Maram verdi porazad",
                       "capacity": "45 person",
                       }
            isfahan = {"main_city": "Isfahan",
                       "places_of_interest": ["city of isfahan", "mosque of isfahan", "Qali Qapu Palace"],
                       "ticket_prices": 10000,
                       "guide": "Ali check",
                       "capacity": "20 person",
                       }
            cost = 0
            if name == "tehran":
                cost = tehran["ticket_prices"]
                self.counts -= cost
                self.favorite_place["tehran"] = tehran
            elif name == "isfahan":
                cost = isfahan["ticket_prices"]
                self.counts -= cost
                self.favorite_place["isfahan"] = isfahan
            elif name == "mashhad":
                cost = mashhad["ticket_prices"]
                self.counts -= cost
                self.favorite_place["mashhad"] = mashhad
            if self.counts < 0:
                print("you don't have enough money.")

            else:
                print(
                    f"you have enough money\nyour many is:{self.counts}Rial.")

    def show_list_places(self):

        for place, places in self.favorite_place.items():
            if place in ["tehran", "mashhad", "isfahan"]:
                print("List of all places in Tehran:")
                print(f"main city:{places['main_city']}")
                print(f"places of interest:{places['places_of_interest']}")

                print(f"ticket prices:{places['ticket_prices']}")
                print(f"guide:{places['guide']}")
                print(f"capacity:{places['capacity']}")

