from lists import Lists

new_list = Lists()



def controller_list(pi):
    print("Hello, welcome to the second chapter. Here you can check the operations related to the changes.")
    while True:
        part1 = "1-Create a guest list\n2-Guest reviews\n3-Changing the guest list"
        part2 = "4-Vehicles\n5-Show guest list\n6-Emergency situation\n7-sights\n8-exit\nEnter your opration please:"

        opration = input(f"Oprations:\n{part1}\n{part2}")
        if opration == "1":
            while True:
                number = int(input("Please enter the number of your guests:"))
                new_list.names(number)
                if pi.questions() == "no":
                    break
        elif opration == "2":
            while True:
                number = int(input("Please enter the id of your guest:"))
                new_list.greeting(number)
                if pi.questions() == "no":
                    break
        elif opration == "3":
            while True:
                number = int(input(
                    "1-Increase the guest list\n2-Decrease the guest list\nplease select one of the following operations to change the guest list:"))
                new_list.changing_the_guest_list(number)
                if pi.questions() == "no":
                    break
        elif opration == "4":
            while True:
                name = input(
                    "Please enter the name of the vehicle you use to get to school:").strip().lower()
                if pi.questions() == "no":
                    break
                new_list.vehicles(name)
        elif opration == "5":
            while True:
                new_list.print_guest()
                if pi.questions() == "no":
                    break
        elif opration == "6":
            while True:
                opration = int(input(
                    "Enter the maximum number of guests you can invite:"))
                new_list.emergency_situation(opration)
                if pi.questions() == "no":
                    break
        elif opration == "7":
            while True:
                number = int(input("Please enter the number of cities you want to travel to:"))
                new_list.sights(number)
                if pi.questions() == "no":
                    break
        elif opration == "8":
            if pi.exit()=="yes":
                break
        else:
            print(
                "The desired operation does not exist. Please re-enter the desired operation.")
            continue




