

class Lists:
    def __init__(self):
        self.list_names = []
        self.list_vehicle = ["car", " motorcycle",
                             "bus", "subways", "helicopter", "on foot"]
        self.list_sights = []
        self.id = 1

    def names(self, number):
        for n in range(number):
            name = input("Enter your name guest:").strip().lower()
            self.list_names.append(name)
            print(f"Your guest name has this id:{self.id}")
            self.id += 1

    def greeting(self, index_name):
        if index_name < self.id:
            print(f"Hi {self.list_names[index_name]} welcome to my party. ")
        else:
            print("Sorry, but the entered ID is not registered for the guest.")

    def changing_the_guest_list(self, number):
        print("")
        if number == 1:
            name = input("Enter your name guest:").strip().lower()
            self.list_names.append(name)
            self.id += 1
            print(
                f"Your guest was successfully added and has this id:{self.id}")
        elif number == 2:
            name = input("Enter your name guest:").strip().lower()
            self.list_names.remove(name)
            self.id -= 1
            print(f"Your guest named {name} was successfully deleted. ")

    def vehicles(self, vehicle):
        
        if vehicle == self.list_vehicle[0]:
            print(
                f"Your vehicles:{vehicle}\nIt's very good, but it can be said that in big cities it takes a little time due to traffic.")
        elif vehicle == self.list_vehicle[1]:
            print(
                f"Your vehicles:{vehicle}\nIt's really great. I also want to go to university on a motorcycle in the future.")
        elif vehicle == self.list_vehicle[2]:
            print(
                f"Your vehicles:{vehicle}\nI also travel part of my route by this vehicle and I can say that it is a bit annoying, especially when you are standing.")
        elif vehicle == self.list_vehicle[3]:
            print(
                f"Your vehicles:{vehicle}\nI also use this vehicle for part of my journey, and I can say that it is more convenient than the bus and there are no traffic problems..")
        elif vehicle == self.list_vehicle[4]:
            print(
                f"Your vehicles:{vehicle}\nIt's very good, I think you are very rich.")
        elif vehicle == self.list_vehicle[5]:
            print(
                f"Your vehicles:{vehicle}\nI do the same. It's a little difficult, but it's good for your health.")
        else:
            print(
                f"Your vehicles:{vehicle}\nSorry, I haven't tried this vehicle, but I think it should be interesting.")

    def print_guest(self):

        print(f"list names of your guests:{self.list_names}")
        print(f"number of guest:{len(self.list_names)}")

    def emergency_situation(self, lengh_table):

        if lengh_table < self.id:
            while lengh_table != self.id:
                guest=self.list_names.pop()
                print(
                    f"Sorry {guest}, there was a problem and the party has been canceled.")
                self.id-=1
        else:
            print("There is no problem")

    def sights(self, number):
        for n in range(number):
            name = input("Enter your name guest:").strip().lower()
            self.list_sights.append(name)
        print(f"your list is travel:{self.list_sights}")
        print(f"your list is travel(sorted):{sorted(self.list_sights)}")
