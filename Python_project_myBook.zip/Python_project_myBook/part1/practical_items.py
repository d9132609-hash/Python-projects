class PracticalItems:
    def __init__(self):
        pass

    def questions(self):
        while True:
            question = input("Do you want to continue?(yes/no):")
            if question.lower() == "yes":
                break
            elif question.lower() == "no":
                break

            else:
                print("please enter your yes or no")
        return question

    def exit(self):
        while True:
            question = input("Do you want to exit?(yes/no):")
            if question.lower() == "yes":
                print("Thank you for using my app. I hope you have a good day.")
                break
            elif question.lower() == "no":

                break
            else:
                print("please enter your yes or no")
        return question
    


  
