
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),'..')))
from part1.practical_items import PracticalItems
pi=PracticalItems()
while True:
    opreation=int(input("Enter your part please:\n1-part1(Educational concepts)\n2-part2(projects)\n3-exit"))
    if opreation==3:
        pi.exit()