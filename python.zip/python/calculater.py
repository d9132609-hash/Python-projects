from practical import qustion
print("Hi welcome to my calculator\operations:\n1-sum\n2-sub\n3-mul\n4-div\n5-exponent\n6-is number odd or even")
while True:
    operation = int(input("Please enter your operation\noperation:"))
    number1 = int(input("Enter your number please:"))
    if operation == 5:
        to_exponent = int(input("Enter your number for to exponent please:"))
        print(f" your number is to exponent: {number1**to_exponent} ")
    elif operation == 6:
        if number1 % 2 == 0:
            print("your number is even")
        elif number1 % 2 == 1:
            print("your number is odd")
    elif operation  in [1, 2, 3, 4]:

        number2 = int(input("Enter your second number please:"))

        if operation == 1:
            print(f"your sum numbers:{number1+number2}")
        elif operation == 2:
            print(f"your sub numbers:{number1-number2}")
        elif operation == 3:
            print(f"your mul numbers:{number1*number2}")
        elif operation == 4:
            print(f"your div numbers:{number1/number2}")
        else:
            print("we haven't your operation")
        if qustion()=="no":
            break

