

# science-camp


def science_camp():
    student = int(input("Enter the number of students: "))

    entrance_fee = 20000
    closing_fee = 150000
    reception_fee = 5000
    van = 10
    capacity = student//van
    if (student % van) != 0:
        capacity += 1
    total = student*(entrance_fee + reception_fee)
    if student < van:
        total = total + closing_fee
    for i in range(capacity):
        total = total + closing_fee

    per_student = total//student
    print(f"Per student: {per_student}")


# Karting
def karting():
    age = int(input("Enter your age :"))
    if age <= 10:
        print("You are not able to participate because you are not old enough.")
    else:
        height = int(input("Enter your height :"))
        if height <= 140:
            print("You are not able to participate because you are not tall enough.")
        else:
            print("You are able to participate in Karting.")


def control():
    while True:

        print("Hi \nopreations:\n1-science-camp\n2-Karting")
        opration = int(input("please enter your opration:"))
        if opration in (1, 2):
            if opration == 1:
                science_camp()
            elif opration == 2:
                karting()
        else:
            print("your opration is not correct")
            continue

        question = input("Do you want to continue? (yes/no): ")

        if question.lower() == "no":
            print("Thank you very much for using our program. Have a nice day.")
            break
        elif question not in ("yes", "no"):
            print("please enter yes or no")


control()
