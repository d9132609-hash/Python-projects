import math
def wind_weight_index():
    wind_speed=float(input("Enter your wind speed:"))
    time=float(input("Enter your wind speed:"))
    wind_weight_index=13.12+0.6215*time-11.37*math.pow(wind_speed,0.16)+0.3965*math.pow(wind_speed,0.16)*time
    print(f" wind weight index(in 10m) is:{wind_weight_index}")
wind_weight_index()
