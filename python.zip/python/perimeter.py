import math
PI = 3.14


def volume_of_the_cylinder():
    radius = float(input("Enter your radius for cylinder:"))
    height = float(input("Enter your radius for cylinder:"))
    volume_of_the_cylinder = height*math.pow(radius, 2)*PI
    print(f"Volume of the cylinder is:{volume_of_the_cylinder} ")


# volume_of_the_cylinder()
def volume_of_a_sphere():
    radius = float(input("Enter your radius:"))
    volume_of_a_sphere = (4/3)*PI*math.pow(radius, 3)
    print(f"volume of a sphere is:{volume_of_a_sphere}")


volume_of_a_sphere()
