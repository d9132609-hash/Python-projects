import math
PI = 3.14


def equilateralArea():
    base = float(input("Enter your base:"))
    height = float(input("Enter your height:"))
    area = base*height/2
    print(f"your equilateralArea is: {area}")
# equilateralArea()


def the_volume_of_the_total_area_cylinder():
    radius = float(input("Enter your base:"))
    height = float(input("Enter your height:"))
    the_volume_of_the_total_area_cylinder = 2 * \
        PI*radius*height+2*PI*math.pow(radius, 2)
    print(
        f"The volume of the total area is:{the_volume_of_the_total_area_cylinder}")


def area_of_a_sphere():
    radius = float(input("Enter your radius:"))
    area_of_a_sphere = 4*PI*math.pow(radius, 2)
    print(f"volume of a sphere is:{area_of_a_sphere}")


#area_of_a_sphere()
def polygon_area():
    polygon=int(input("Enter your polygon:"))
    length_polygon=float(input("Enter your length polygon:"))
    polygon_area=(polygon*math.pow(length_polygon,2))/(4+math.tan(PI/polygon))
    print(f"Polygon area is:{polygon_area}")
polygon_area()
