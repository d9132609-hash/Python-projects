# my code python
from practical import qustion
while True:
    





    
    if qustion()=="no":
        break




