def budget():
    commodity_prices = int(input("Enter your commodity prices:"))
    years = int(input("Enter your years: "))
    inflation_rates = float(input("Enter your inflation rates:"))
    print("year", "     ","commodity prices")
    print("____________________________________")
    for i in range(1, years+1):
        commodity_prices += (commodity_prices*inflation_rates/100)

        print(i, "        ", commodity_prices)


budget()
