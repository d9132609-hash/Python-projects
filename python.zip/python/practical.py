
def qustion():
    while (True):
        qustion1 = input("Do you want to continue?(yes/no): ")
        if qustion1.lower() == "yes":
            break
        elif qustion1.lower() == "no":
            print("Thank you for using my app. I hope you have a good day.")
            break
        else:
            print("please enter your yes or no")
    return qustion1

# Fibonacci sequence
def fibonacci(number):
    number1 = 1
    number2 = 1
    print("Your Fibonacci sequence answer:")
    if number == 1:
        print(number1)
    elif number == 2:
        print(number2)
        print(number1)
    else:
        print(number1)
        print(number2)
        i = 3
        while i <= number:
            number3 = number1+number2
            print(number3)
            number1 = number2
            number2 = number3
            i += 1
