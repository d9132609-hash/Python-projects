while True:
    sum = 0
    number1 = int(input("enter your first number:"))
    number2 = int(input("enter your secound number:"))
    if number1==0 and number2==0:
        print("good bye")
        break
    temp=number2
    if number2<0:
        temp= -number2
    for i in range(1,temp+1):
        sum+=number1
    if number2<0:
        sum=-sum
    print(f"{number1} * {number2} = {sum}")


