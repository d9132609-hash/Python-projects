#include <iostream>
#include <cmath>
const double pi{3.14};
void volumeOfTheCylinder(){
    std::cout<<"Enter your radius for Cylinder:";
    double radius{};
    std::cin>>radius;
    std::cout<<"Enter your height for Cylinder:";
    double height{};
    std::cin>>height;

    double volumeOfTheCylinder{height*(std::pow(radius,2))*pi};
    std::cout<<"Volume of the cylinder is:"<<volumeOfTheCylinder<<'\n';


}
void volumeOfASphere(){
    std::cout << "Enter your height for Sphere";
    double radius{};
    std::cin >> radius;
    
    double volumeOfASphere=(4/3)*pi*std::pow(radius,3);
    std::cout<<"volume of a sphere is:"<<volumeOfASphere<<'\n';

}