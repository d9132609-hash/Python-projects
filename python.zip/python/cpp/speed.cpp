#include <iostream>
#include <cmath>
const double pi{3.14};
// namespace std::cout;
// namespace std::cin;
void windWeightIndex()
{
    std::cout << "Enter your wind speed:";
    double windSpeed{};
    std::cin >> windSpeed;
    std::cout << "Enter your time:";
    double time{};
    std::cin >> time;
    double windWeightIndex{13.12 + (0.6215 * time) - (11.37 * std::pow(windSpeed, 0.16)) +( 0.3965 * std::pow(windSpeed, 0.16) * time)};
    std::cout << "wind weight index(in 10m) is:" << windWeightIndex << '\n';
}