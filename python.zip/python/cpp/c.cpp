#include <iostream>
#include <stdexcept>

int main()
{
    while (true)
    {
        std::cout << "Enter your size number for average: ";
        int size{};
        std::cin >> size;

        if (size <= 0)
        {
            std::cerr << "Error: You entered an invalid argument.\n";
            continue; // ادامه دادن به درخواست مجدد ورودی
        }

        double total = 0;
        for (int i = 0; i < size; i++)
        {
            std::cout << "Enter your number for average: ";
            double number{};
            std::cin >> number;
            total += number;
        }

        double result = total / size;
        std::cout << "Your average is: " << result << '\n';

        std::cout << "Do you want to continue? (yes/no)\n";
        std::string question{};
        std::cin >> question;

        if (question == "no")
        {
            break;
        }
        else if (question != "yes")
        {
            std::cerr << "Error: Invalid input.\n";
        }
    }

    return 0;
}
