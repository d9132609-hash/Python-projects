#include <iostream>
#include <string>
#include <cmath>
#include <stdexcept>
int main()
{

    while (true)
    {
        std::cout << "Enter your size number for avage:";
        int size{};
        std::cin >> size;
        if (size <= 0)
        {
            std::cerr << "Error: You entered an invalid argument.\n";
            continue;
        }

        double numbers{};

        for (int i = 0; i < size; i++)
        {
            int x{i + 1};
            std::cout << "Enter your number " << x << " for avage:";
            double number{};
            std::cin >> number;
            numbers += number;
        }

        double result = numbers / size;
        std::cout << "Your avage is: " << result << '\n';
        std::cout << "Do you want to continue?(yes/no):";
        std::string question{};
        std::cin >> question;
        if (question == "yes")
        {
            continue;
        }
        else if (question == "no")
        {
            break;
        }
        else
        {
            std::cerr << "Error: You entered an invalid argument.\n";
        }
    }
    return 0;
}