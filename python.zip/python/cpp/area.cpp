#include <iostream>
#include <cmath>
const double pi{3.14};
void equilateralArea()
{
    std::cout << "Enter your base triangle:";
    float base{};
    std::cin >> base;
    std::cout << "Enter your eighth triangle:";
    float height{};
    std::cin >> height;
    float area = height * base / 2;
    std::cout << "your area is:" << area << '\n';
}
void theVolumeOfTheTotalArea()
{
    std::cout << "Enter your radius for Cylinder:";
    double radius{};
    std::cin >> radius;
    std::cout << "Enter your height for Cylinder:";
    double height{};
    std::cin >> height;
    double theVolumeOfTheTotalArea = 2 * pi * radius * height + 2 * pi * std::pow(radius, 2) * height;
    std::cout << "The volume of the total area is:" << theVolumeOfTheTotalArea << '\n';
}
void areaOfASphere()
{
    std::cout << "Enter your height for Sphere:";
    double radius{};
    std::cin >> radius;
    double areaOfASphere = 4 * pi * std::pow(radius, 2);
    std::cout << "area of a sphere is:" << areaOfASphere << '\n';
}
void polygonalArea()
{
    std::cout << "Enter your polygon:"; 
    int polygon{};
    std::cin >> polygon;
    std::cout << "Enter your length polygon:";
    double lengthPolygon {};
    std::cin >> lengthPolygon;
    double polygonalArea = (polygon * std::pow(lengthPolygon, 2)) / (4 + std::tan(pi / polygon));
    std::cout << "Polygon area is:" << polygonalArea << '\n';
}