def divider(total, people, percent, status, currency):
    if status == "1":
        while True:
            try:
                percent_array = percent.split(" ")
                array_count = len(percent_array)
                if array_count != people:
                    raise ValueError("Percent is count to equal to people count")
                if abs(sum(float(x) for x in percent_array) - 100) > 0.001:
                    raise ValueError("Total percent must be 100")
                break
            except ValueError as e:
                print(f"Error : {e}")
                percent = input("Enter each person percent with space:")
        result = [total * (float(p) / 100) for p in percent_array]
        print(f"Total expenses:{total:,.3f}{currency}")
        print(f"Number of people:{people}")

        for id , count in enumerate(result,1):
            print(f"Person{id}: be must pay{count:,.3f}{currency}")
        print("-----------------------------------------------")

    elif status == "2":
        result = total / people
        print(f"Total expenses:{total:,.3f}")
        print(f"Number of people:{people}")
        print(f"Each person be must {result:,.3f}{currency}")
        print("-----------------------------------------------")
    else:
        print(f"Status {status} is application is invalid ")
def show():
    while True:
        try:
            total_input = float(input("Enter total amount: "))
            break
        except ValueError as e:
            print(f"Error : {e}")
    while True:
        try:
            people_input = int(input("Enter your number of person: "))
            if people_input < 1:
                raise ValueError("People count is count to equal to 1")
            break
        except ValueError as e:
            print(f"Error : {e}")
    while True:

            status_input = (input("Status:\n1-For not equal expenses\n2-For equal expenses\nEnter your status:"))
            if status_input in ["1","2"]:

               break
            else:
                print(f"Status : {status_input} is not valid")
    percent_inputs = ""
    if status_input == "1":
        percent_inputs = input("Enter each person percent with space:")
    divider(total_input, people_input, percent_inputs, status_input, "Real")

