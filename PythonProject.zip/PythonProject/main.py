import calculator
import divider
import edit_text



def main():
   print("Welcome to the my app!")
   operation = input("Operations:\n1-Calculator\n2-Divider\n3-Edit text\n4-Exit\nEnter your operation:")
   while True:
       if operation == "1":
           calculator.show()
           break
       elif operation == "2":
           divider.show()
           break
       elif operation == "3":
           edit_text.show()
           break
       elif operation == "4":
           question =input("Are your sure?(yes/no)").lower()
           if question in [ "yes","no"]:
               break
           else:
               print("Please enter yes or no")
       else:
            print("sorry you don 't have any of your expectations .")


if __name__ == '__main__':
    main()
