import re
from collections import Counter
import pypdf



def count(text):
    lower_text = text.lower()
    words = re.findall(r"\b\w+\b",lower_text)
    word_counts = Counter(words)
    return word_counts.most_common(10)
def show():
    print("Welcome to my edit text. ")
    s = "1-Copy past\n2-Read from text file\n3-Read from pdf files\n4-Read all pdf files"
    status = input(f"Operations:\n{s}\nEnter your operation: ")
    if status =="1":
        text = input("Please enter your text: ")
    elif status =="2":
        address = input("Please enter your address text file: ")
        f = open(address)
        text = f.read()
     elif status =="3":
         address = input("Please enter your address pdf file: ")
         number_of_page = int(input("Please enter your number of pages: "))
         render = pypdf.PdfRender(address)
         page = render.pages[number_of_page]
         text = page.extract_text()
   # elif status =="4":
   #     address = input("Please enter your address pdf file: ")
   #     render = pypdf.PdfRender(address)
   #     number_of_page = len(render.pages)
   #     for i in range(number_of_page):
   #         page = render.pages[i]
   #         add = page.extract_text()
   #         if add:
   #             with open("main.txt","a",encoding="utf-8") as f:
   #                 f.write(add)
   #     with open(r"main.txt","r",encoding="utf-8") as f:
   #         text = f.read()
    else:
        print("Please enter valid input")
        text = ""
    word_counter = count(text)
    for word, counts in word_counter:
        print(f"{word}: {counts}")

