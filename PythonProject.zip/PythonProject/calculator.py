def calculator(monthly_income, tax_rate, monthly_express, currency):
    monthly_tax = monthly_income * (tax_rate / 100)
    monthly_full_income = monthly_income - (monthly_tax + monthly_express)

    year_income = monthly_income * 12
    year_tax = monthly_tax * 12

    year_express = monthly_express * 12
    year_full_income = year_income - (year_tax + year_express)
    print("------------------------------------------------------")
    print(f"Monthly Income: {monthly_income:,.3f} {currency}")
    print(f"Tax Rate:{tax_rate:,.1f} %")
    print(f"Monthly Tax: {monthly_tax:,.3f} {currency}")
    print(f"Monthly full Income : {monthly_full_income:,.2f} {currency}")
    print(f"Year Income: {year_income:,.3f} {currency}")
    print(f"Year Tax: {year_tax:,.2f} {currency}")
    print(f"Year Express: {year_express:,.3f} {currency}")
    print(f"Year Full Income: {year_full_income:,.3f} {currency}")
    print("------------------------------------------------------")
def show():
    try:
        monthly_income_inputs = float(input("Enter your monthly income: "))
        tax_rate_inputs = float(input("Enter your tax rate(%): "))
        monthly_express_inputs = float(input("Enter your monthly express rate: "))
        calculator(monthly_income_inputs, tax_rate_inputs, monthly_express_inputs, "Rial")
    except ValueError as e:
        print(f"Error: {e}")